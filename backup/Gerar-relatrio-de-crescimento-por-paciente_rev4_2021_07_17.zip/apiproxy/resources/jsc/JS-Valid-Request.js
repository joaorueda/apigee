   try {
     var pathSuffix = context.getVariable("proxy.pathsuffix");
     if (pathSuffix.search("progress")==-1 || pathSuffix.search("accounts")==-1) {
         context.setVariable("error-400",true);
     }
 } catch (e){
     print("Error JS-Valid-Request.js",e);
     context.setVariable("error-500",true);
 }
 