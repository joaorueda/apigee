  
     try {
         var pathSuffix = context.getVariable("proxy.pathsuffix");
         var id = pathSuffix.split("/");
         if (!isEmail(id[2])){
             throw id[2] + " não é um email válido!";
         }
         if(id[2]!="joaomarcosrueda@gmail.com"){
            context.setVariable("error-404",true);    
         } else {
             context.setVariable("error-404",false);    
         }
     } catch (e){
         print("Error JS-Valid-Email.js",e);
         context.setVariable("error-500",true);
     }
 
     function isEmail(str){
         var er = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
         return er.test(str);
     }
 