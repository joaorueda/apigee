 
     try {
         var pathSuffix = context.getVariable("proxy.pathsuffix");
         var id = pathSuffix.split("/");
         if (!isNumeric(id[2])){
             throw id[2] + " não é um número válido!";
         }
         if(id[2]!="1"){
            context.setVariable("error-404",true);    
         } else {
             context.setVariable("error-404",false);    
         }
     } catch (e){
         print("Error JS-ValidaID.js",e);
         context.setVariable("error-500",true);
     }
 
     function isNumeric(str){
         var er = /^[0-9]+$/;
         return er.test(str);
     }
 